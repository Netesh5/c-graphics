#include<stdio.h>
#include<conio.h>
#include<graphics.h>
void road();
void road()
{cleardevice();
int gd=DETECT,gm,x,y,i,n;
x=getmaxx()/2;
y=getmaxy()/2;
line(x-150,0,x-150,y+1000);
line(x+150,0,x+150,y+1000);
line(x,y-50,x,y+20);
line(x,y+80,x,y+150);
line(x,y+190,x,y+260);
line(x,y-90,x,y-160);
line(x,y-200,x,y-270);
getch();
closegraph();
}
