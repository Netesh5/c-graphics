
#include<graphics.h>
#include<dos.h>
void loading();
int main()
{
  loading();
  return 0;
}
void loading()
{
  int gd=DETECT,gm,x,y,i;
initgraph(&gd,&gm,"");
  x=getmaxx()/2;
  y=getmaxy()/2;
  for(i=0;i<=100;i=i+10)
{ int border_color = WHITE;
  setfillstyle(SOLID_FILL,RED);
  circle(x,y-i,30);
  floodfill(x,y-i,border_color);
  delay(50);
  cleardevice();
}
for(i=0;i<=100;i=i+10)
{ int border_color = WHITE;
  setfillstyle(SOLID_FILL,BLUE);
  circle(x,y-100+i,30);
  floodfill(x,y-100+i,border_color);
  delay(50);
  cleardevice();
}
for(i=0;i<=100;i=i+10)
{ int border_color = WHITE;
  setfillstyle(SOLID_FILL,GREEN);
  circle(x,y+i,30);
  floodfill(x,y+i,border_color);
  delay(50);
  cleardevice();
}
for(i=0;i<=100;i=i+10)
{ int border_color = WHITE;
  setfillstyle(SOLID_FILL,YELLOW);
  circle(x,y+100-i,30);
  floodfill(x,y+100-i,border_color);
  delay(50);
  cleardevice();
}
for(i=0;i<=100;i=i+10)
{ int border_color = WHITE;
  setfillstyle(HATCH_FILL,BROWN);
  circle(x+i,y,30);
  floodfill(x+i,y,border_color);
  delay(50);
  cleardevice();
}
for(i=0;i<=100;i=i+10)
{ int border_color = WHITE;
  setfillstyle(HATCH_FILL,MAGENTA);
  circle(x+100-i,y,30);
  floodfill(x+100-i,y,border_color);
  delay(50);
  cleardevice();
}
for(i=0;i<=100;i=i+10)
{ int border_color = WHITE;
  setfillstyle(HATCH_FILL,RED);
  circle(x-i,y,30);
  floodfill(x-i,y,border_color);
  delay(50);
  cleardevice();
}
for(i=0;i<=100;i=i+10)
{ int border_color = WHITE;
  setfillstyle(HATCH_FILL,RED);
  circle(x-100+i,y,30);
  floodfill(x-100+i,y,border_color);
  delay(50);
  cleardevice();
}
  getch();
  closegraph();
}
