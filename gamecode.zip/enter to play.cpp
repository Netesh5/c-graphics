#include<graphics.h>
void enter();
void enter()
{
    int gd=DETECT,gm,i;
    initgraph(&gd,&gm," ");
    int x=getmaxx()/2;
    int y=getmaxy()/2;
    for(i=1;i<=8;i=i+2)
    {
     setcolor(i);
    settextstyle(3,HORIZ_DIR,1+i);
    outtextxy(155,205,"CAR GAME");
    delay(700);
    }
    getch();
    closegraph();
}
