#include <graphics.h>
void loading();
void road();
// main code
int main()
{
      loading();
    road();
    getch();
    closegraph();
    return 0;
}
